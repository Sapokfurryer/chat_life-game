const fs = require("fs");
const https = require("https");
const express = require("express");
const cors = require("cors");
const fetch = require("node-fetch");  // 💡 설치 필요: npm install node-fetch

const app = express();

app.use(cors());
app.use(express.json());

app.post("/api/generate", async (req, res) => {
  const { model = "mistral", prompt, stream = false } = req.body;

  console.log("[🔐 수신된 프롬프트]:", prompt);

  try {
    const ollamaRes = await fetch("http://localhost:11434/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        prompt,
        stream,
      }),
    });

    const data = await ollamaRes.json();

    if (!data.response) {
      console.error("❌ LLM 응답에 'response' 필드가 없습니다");
      return res.status(500).json({ error: "Invalid LLM response" });
    }

    res.json({ response: data.response });

  } catch (err) {
    console.error("❌ LLM 요청 중 오류:", err);
    res.status(500).json({ error: "LLM request failed" });
  }
});

const options = {
  key: fs.readFileSync("localhost-key.pem"),
  cert: fs.readFileSync("localhost.pem"),
};

https.createServer(options, app).listen(3000, () => {
  console.log("🔐 HTTPS 서버 실행 중: https://localhost:3000");
});
